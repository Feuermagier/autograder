public class Test {
	public int x;
	
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return x;
	}
}