public class Test {
	public String x = "abc";
	
	void foo() {
		String a = "";
		String b = "x";
	}
}