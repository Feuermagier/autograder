import java.util.*;

public class Test {

    public static void main(String... args) {
		boolean x = "a" == "a";
		boolean y = "a" == "a";
	}

}