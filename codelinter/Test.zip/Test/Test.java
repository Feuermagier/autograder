import java.util.*;

public class Test extends Object {

    public static void main(String... args) {
		ArrayList<Integer> a = new ArrayList<>();
		for (int i = 0; i < a.size(); i++) {
			System.out.println(a.get(i));
		}
	}

}