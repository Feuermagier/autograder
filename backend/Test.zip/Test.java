public final class Test {

    void foo() {
    	assert 1 == 1;
	}
}
