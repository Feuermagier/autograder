public class Test {

    public static void main(String... args) {
		boolean x = "a" == "a";
	}
}