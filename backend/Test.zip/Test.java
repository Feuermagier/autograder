import java.io.File;

public final class Test {

    void foo() {
        assert 1 == 1;
	}
}
