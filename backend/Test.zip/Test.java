public class Test {

    public static void mai(String... args) {
		Object o = new Object()
	}
}